## Packages
framer-motion | Animation library for smooth transitions
date-fns | Date formatting for chat logs
lucide-react | Icons for the UI (already in base but ensuring availability)
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind classes safely

## Notes
The app connects to a Telegram Bot backend.
API endpoints are defined in shared/routes.ts.
The dashboard needs to poll for new messages or use a refresh button.
