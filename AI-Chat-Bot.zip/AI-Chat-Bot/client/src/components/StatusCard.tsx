import { useBotStatus, useToggleBot } from "@/hooks/use-bot";
import { Power, Activity, ShieldCheck } from "lucide-react";
import { cn } from "@/lib/utils";

export function StatusCard() {
  const { data: status, isLoading } = useBotStatus();
  const toggleBot = useToggleBot();

  if (isLoading) return <StatusCardSkeleton />;

  const isOnline = status?.online;

  return (
    <div className="grid gap-4 md:grid-cols-3">
      {/* Main Status Card */}
      <div className="col-span-1 md:col-span-2 overflow-hidden rounded-2xl border border-border bg-card shadow-sm transition-all hover:shadow-md">
        <div className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Bot Status</p>
              <h3 className="mt-2 text-2xl font-bold tracking-tight text-foreground">
                {isOnline ? "Active & Listening" : "Offline"}
              </h3>
              <p className="mt-1 text-sm text-muted-foreground">
                {isOnline 
                  ? "The bot is currently processing messages." 
                  : "The bot is currently disabled."}
              </p>
            </div>
            <div className={cn(
              "flex h-12 w-12 items-center justify-center rounded-full transition-colors",
              isOnline ? "bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400" : "bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400"
            )}>
              <Activity className="h-6 w-6" />
            </div>
          </div>

          <div className="mt-6">
            <button
              onClick={() => toggleBot.mutate(!isOnline)}
              disabled={toggleBot.isPending}
              className={cn(
                "inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold transition-all duration-200",
                isOnline 
                  ? "bg-red-50 text-red-600 hover:bg-red-100 border border-red-200 dark:bg-red-900/20 dark:border-red-900/50" 
                  : "bg-green-50 text-green-600 hover:bg-green-100 border border-green-200 dark:bg-green-900/20 dark:border-green-900/50",
                toggleBot.isPending && "opacity-50 cursor-not-allowed"
              )}
            >
              <Power className="h-4 w-4" />
              {toggleBot.isPending ? "Updating..." : (isOnline ? "Stop Bot" : "Start Bot")}
            </button>
          </div>
        </div>
        
        {/* Progress bar effect at bottom */}
        <div className="h-1 w-full bg-muted">
          <div 
            className={cn("h-full transition-all duration-500", isOnline ? "w-full bg-green-500" : "w-0 bg-red-500")} 
          />
        </div>
      </div>

      {/* Info Card */}
      <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
            <ShieldCheck className="h-5 w-5" />
          </div>
          <div>
            <p className="text-sm font-medium text-muted-foreground">Identity</p>
            <p className="font-semibold text-foreground">
              {status?.username ? `@${status.username}` : "Unknown"}
            </p>
          </div>
        </div>
        <div className="mt-4 pt-4 border-t border-border">
          <p className="text-xs text-muted-foreground">
            Connection secure. Webhook active.
          </p>
        </div>
      </div>
    </div>
  );
}

function StatusCardSkeleton() {
  return (
    <div className="grid gap-4 md:grid-cols-3">
      <div className="col-span-1 md:col-span-2 h-40 rounded-2xl bg-muted animate-pulse" />
      <div className="h-40 rounded-2xl bg-muted animate-pulse" />
    </div>
  );
}
