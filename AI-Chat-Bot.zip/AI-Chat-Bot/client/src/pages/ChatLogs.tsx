import { ChatMessage } from "@/components/ChatMessage";
import { useMessages, useClearMessages } from "@/hooks/use-bot";
import { Trash2, RefreshCw, MessageSquareOff } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function ChatLogs() {
  const { data: messages, isLoading, refetch, isRefetching } = useMessages();
  const clearMessages = useClearMessages();

  // Sort messages by date descending (newest first)
  const sortedMessages = messages ? [...messages].sort((a, b) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  ) : [];

  return (
    <div className="flex h-[calc(100vh-4rem)] flex-col gap-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Chat Logs</h1>
          <p className="text-muted-foreground mt-2">Real-time view of bot interactions.</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => refetch()}
            className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors rounded-lg hover:bg-muted"
          >
            <RefreshCw className={`h-4 w-4 ${isRefetching ? 'animate-spin' : ''}`} />
            Refresh
          </button>
          <button
            onClick={() => {
              if (confirm("Are you sure you want to clear all chat history?")) {
                clearMessages.mutate();
              }
            }}
            disabled={clearMessages.isPending || sortedMessages.length === 0}
            className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-red-600 hover:text-red-700 bg-red-50 hover:bg-red-100 dark:bg-red-900/20 dark:hover:bg-red-900/40 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Trash2 className="h-4 w-4" />
            Clear History
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-hidden rounded-2xl border border-border bg-card shadow-sm flex flex-col">
        {isLoading ? (
          <div className="flex-1 flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
          </div>
        ) : sortedMessages.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground p-8">
            <MessageSquareOff className="h-12 w-12 mb-4 opacity-20" />
            <p className="text-lg font-medium">No messages yet</p>
            <p className="text-sm">Start a conversation with your bot on Telegram to see logs here.</p>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto p-4 space-y-2">
            <AnimatePresence>
              {sortedMessages.map((msg, idx) => (
                <ChatMessage
                  key={msg.id}
                  index={idx}
                  role={msg.role}
                  content={msg.content}
                  createdAt={msg.createdAt}
                />
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>
    </div>
  );
}
