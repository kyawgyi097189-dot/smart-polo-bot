import { StatusCard } from "@/components/StatusCard";
import { useMessages } from "@/hooks/use-bot";
import { Activity, MessageSquare, TrendingUp, Users } from "lucide-react";

export default function Dashboard() {
  const { data: messages } = useMessages();
  
  // Calculate simple stats
  const totalMessages = messages?.length || 0;
  const userMessages = messages?.filter(m => m.role === 'user').length || 0;
  const botMessages = messages?.filter(m => m.role === 'assistant').length || 0;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Dashboard</h1>
        <p className="text-muted-foreground mt-2">Overview of your AI Bot's performance and status.</p>
      </div>

      <StatusCard />

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard 
          title="Total Messages" 
          value={totalMessages} 
          icon={MessageSquare}
          trend="+12% from yesterday"
        />
        <StatCard 
          title="User Queries" 
          value={userMessages} 
          icon={Users}
          className="text-blue-500"
        />
        <StatCard 
          title="AI Responses" 
          value={botMessages} 
          icon={BotIcon}
          className="text-purple-500"
        />
        <StatCard 
          title="Response Rate" 
          value="98.5%" 
          icon={Activity}
          className="text-green-500"
        />
      </div>

      <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Recent Activity</h3>
            <p className="text-sm text-muted-foreground">Latest interactions with the bot.</p>
          </div>
        </div>
        
        {/* Mini chart placeholder - in real app use Recharts */}
        <div className="h-48 w-full rounded-lg bg-muted/20 flex items-center justify-center border border-dashed border-border">
          <div className="text-center">
            <TrendingUp className="mx-auto h-8 w-8 text-muted-foreground/50" />
            <p className="mt-2 text-sm text-muted-foreground">Activity chart visualization would go here</p>
          </div>
        </div>
      </div>
    </div>
  );
}

// Helper components for Dashboard
import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

function BotIcon(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M12 8V4H8" />
      <rect width="16" height="12" x="4" y="8" rx="2" />
      <path d="M2 14h2" />
      <path d="M20 14h2" />
      <path d="M15 13v2" />
      <path d="M9 13v2" />
    </svg>
  )
}

function StatCard({ 
  title, 
  value, 
  icon: Icon, 
  trend,
  className 
}: { 
  title: string; 
  value: string | number; 
  icon: LucideIcon | typeof BotIcon;
  trend?: string;
  className?: string;
}) {
  return (
    <div className="rounded-xl border border-border bg-card p-6 shadow-sm transition-all hover:shadow-md">
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium text-muted-foreground">{title}</p>
        <Icon className={cn("h-4 w-4 text-muted-foreground", className)} />
      </div>
      <div className="mt-2 flex items-baseline gap-2">
        <span className="text-2xl font-bold text-foreground">{value}</span>
      </div>
      {trend && (
        <p className="mt-1 text-xs text-green-600 font-medium">
          {trend}
        </p>
      )}
    </div>
  );
}
