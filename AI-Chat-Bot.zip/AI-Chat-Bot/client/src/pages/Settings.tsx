import { useSetting, useUpdateSetting } from "@/hooks/use-bot";
import { Save, Terminal, Zap } from "lucide-react";
import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { motion } from "framer-motion";

export default function Settings() {
  const { data: setting, isLoading } = useSetting("system_prompt");
  const updateSetting = useUpdateSetting();
  
  const { register, handleSubmit, setValue, formState: { isDirty } } = useForm({
    defaultValues: {
      value: "",
    },
  });

  useEffect(() => {
    if (setting) {
      setValue("value", setting.value);
    }
  }, [setting, setValue]);

  const onSubmit = (data: { value: string }) => {
    updateSetting.mutate({
      key: "system_prompt",
      value: data.value,
    });
  };

  return (
    <div className="max-w-4xl space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Settings</h1>
        <p className="text-muted-foreground mt-2">Configure how your AI Bot behaves and responds.</p>
      </div>

      <div className="grid gap-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-2xl border border-border bg-card p-6 shadow-sm"
        >
          <div className="flex items-start gap-4">
            <div className="mt-1 flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-indigo-100 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400">
              <Terminal className="h-5 w-5" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-foreground">System Prompt</h3>
              <p className="text-sm text-muted-foreground">
                This prompt defines the AI's personality and instructions. Changes take effect immediately for new messages.
              </p>

              <form onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-4">
                <div className="relative">
                  <textarea
                    {...register("value")}
                    disabled={isLoading}
                    className="w-full h-64 rounded-xl border border-border bg-muted/30 p-4 font-mono text-sm leading-relaxed text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-4 focus:ring-primary/10 transition-all resize-none"
                    placeholder="You are a helpful AI assistant..."
                  />
                  <div className="absolute bottom-4 right-4 text-xs text-muted-foreground pointer-events-none">
                    Markdown supported
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <p className="text-xs text-muted-foreground flex items-center gap-1">
                    <Zap className="h-3 w-3" />
                    Auto-saved to database
                  </p>
                  
                  <button
                    type="submit"
                    disabled={updateSetting.isPending || !isDirty}
                    className="flex items-center gap-2 rounded-lg bg-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/20 transition-all hover:-translate-y-0.5 hover:shadow-xl hover:shadow-primary/30 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
                  >
                    {updateSetting.isPending ? (
                      <div className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                    ) : (
                      <Save className="h-4 w-4" />
                    )}
                    {updateSetting.isPending ? "Saving..." : "Save Changes"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
