import { Telegraf, Markup } from "telegraf";
import { message } from "telegraf/filters";
import { storage } from "./storage";
import OpenAI from "openai";

const botToken = process.env.TELEGRAM_BOT_TOKEN;
const OWNER_ID = 5748897306;

let bot: Telegraf | null = null;
let isRunning = false;

// Global sets to track status for performance
const VIP_USERS = new Set<string>();
const BANNED_USERS = new Set<string>();

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

/**
 * Sync in-memory sets with database state
 */
async function syncPermissions() {
  const users = await storage.getAllTelegramUserIds();
  VIP_USERS.clear();
  BANNED_USERS.clear();
  
  for (const id of users) {
    const user = await storage.getTelegramUser(id);
    if (user?.isVip) VIP_USERS.add(id);
    if (user?.isBanned) BANNED_USERS.add(id);
  }
}

export async function startBot() {
  if (!botToken) {
    console.warn("TELEGRAM_BOT_TOKEN not found, bot will not start");
    return false;
  }

  if (isRunning) return true;

  try {
    // Initial sync
    await syncPermissions();

    bot = new Telegraf(botToken);

    bot.use(async (ctx, next) => {
      const start = Date.now();
      await next();
      const ms = Date.now() - start;
      console.log('Response time: %sms', ms);
    });

    // Start command
    bot.start(async (ctx) => {
      const userId = ctx.from.id;
      const telegramId = userId.toString();
      
      // Upsert user
      const user = await storage.upsertTelegramUser(telegramId);

      if (BANNED_USERS.has(telegramId)) {
        return ctx.reply("🚫 You are banned.");
      }

      if (userId === OWNER_ID) {
        const keyboard = Markup.inlineKeyboard([
          [Markup.button.callback("📊 Users", "users")],
          [Markup.button.callback("📢 Broadcast", "broadcast_info")]
        ]);
        return ctx.reply("👑 OWNER PANEL", keyboard);
      } else if (VIP_USERS.has(telegramId)) {
        return ctx.reply("💎 VIP ACCESS GRANTED. How can I help you?");
      } else {
        return ctx.reply("🤖 Welcome Normal User. How can I help you?");
      }
    });

    // Button Handlers
    bot.action("users", async (ctx) => {
      if (ctx.from?.id !== OWNER_ID) return;
      const count = await storage.getTotalUsersCount();
      await ctx.editMessageText(`📊 Total Users: ${count}`);
    });

    bot.action("broadcast_info", async (ctx) => {
      if (ctx.from?.id !== OWNER_ID) return;
      await ctx.editMessageText("Use command:\n/broadcast your message");
    });

    // Commands
    bot.command("addvip", async (ctx) => {
      if (ctx.from.id !== OWNER_ID) return;
      const args = ctx.message.text.split(" ").slice(1);
      if (args.length === 0) return ctx.reply("Usage: /addvip user_id");
      const targetId = args[0];
      await storage.updateTelegramUserStatus(targetId, { isVip: true });
      VIP_USERS.add(targetId);
      ctx.reply("💎 VIP Added");
    });

    bot.command("removevip", async (ctx) => {
      if (ctx.from.id !== OWNER_ID) return;
      const args = ctx.message.text.split(" ").slice(1);
      if (args.length === 0) return ctx.reply("Usage: /removevip user_id");
      const targetId = args[0];
      await storage.updateTelegramUserStatus(targetId, { isVip: false });
      VIP_USERS.delete(targetId);
      ctx.reply("❌ VIP Removed");
    });

    bot.command("ban", async (ctx) => {
      if (ctx.from.id !== OWNER_ID) return;
      const args = ctx.message.text.split(" ").slice(1);
      if (args.length === 0) return ctx.reply("Usage: /ban user_id");
      const targetId = args[0];
      await storage.updateTelegramUserStatus(targetId, { isBanned: true });
      BANNED_USERS.add(targetId);
      ctx.reply("🚫 User Banned");
    });

    bot.command("broadcast", async (ctx) => {
      if (ctx.from.id !== OWNER_ID) return;
      const text = ctx.message.text.split(" ").slice(1).join(" ");
      if (!text) return ctx.reply("Usage: /broadcast your message");

      const userIds = await storage.getAllTelegramUserIds();
      let sentCount = 0;
      for (const id of userIds) {
        try {
          await ctx.telegram.sendMessage(id, text);
          sentCount++;
        } catch (e) {
          console.error(`Failed to send broadcast to ${id}:`, e);
        }
      }
      ctx.reply(`📢 Broadcast Sent to ${sentCount} users`);
    });

    // Handle text messages
    bot.on(message("text"), async (ctx) => {
      const telegramId = ctx.from.id.toString();
      
      if (BANNED_USERS.has(telegramId)) return;

      const userMessage = ctx.message.text;
      const chatId = ctx.chat.id.toString();
      const messageId = ctx.message.message_id.toString();

      try {
        await storage.addMessage({
          chatId,
          messageId,
          role: "user",
          content: userMessage,
        });

        const systemPromptSetting = await storage.getSetting("system_prompt");
        const systemPrompt = systemPromptSetting?.value || "You are a helpful AI assistant.";

        const response = await openai.chat.completions.create({
          model: "gpt-4o-mini",
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userMessage }
          ],
        });

        const replyText = response.choices[0].message.content || "I'm not sure how to respond.";
        const sentMessage = await ctx.reply(replyText);

        await storage.addMessage({
          chatId,
          messageId: sentMessage.message_id.toString(),
          role: "assistant",
          content: replyText,
        });

      } catch (error) {
        console.error("Error processing message:", error);
        ctx.reply("Sorry, I encountered an error processing your request.");
      }
    });

    bot.launch(() => {
      console.log("Telegram bot started");
      isRunning = true;
    });

    process.once('SIGINT', () => stopBot());
    process.once('SIGTERM', () => stopBot());

    return true;
  } catch (error) {
    console.error("Failed to start bot:", error);
    return false;
  }
}

export function stopBot() {
  if (bot && isRunning) {
    bot.stop("SIGINT");
    bot = null;
    isRunning = false;
    console.log("Telegram bot stopped");
  }
}

export function getBotStatus() {
  return { 
    online: isRunning,
    username: bot?.botInfo?.username 
  };
}
