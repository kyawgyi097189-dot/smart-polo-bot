import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { startBot, stopBot, getBotStatus } from "./bot";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Initialize settings
  await storage.initSettings();

  // Start bot automatically
  startBot().catch(console.error);

  // API Routes
  app.get(api.messages.list.path, async (req, res) => {
    const messages = await storage.getMessages();
    res.json(messages);
  });

  app.post(api.messages.clear.path, async (req, res) => {
    await storage.clearMessages();
    res.status(204).end();
  });

  app.get(api.settings.get.path, async (req, res) => {
    const key = req.params.key;
    const setting = await storage.getSetting(key);
    if (!setting) {
      return res.status(404).json({ message: "Setting not found" });
    }
    res.json(setting);
  });

  app.post(api.settings.update.path, async (req, res) => {
    try {
      const input = api.settings.update.input.parse(req.body);
      const updated = await storage.updateSetting(input);
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.get(api.bot.status.path, (req, res) => {
    res.json(getBotStatus());
  });

  app.post(api.bot.toggle.path, async (req, res) => {
    const { enabled } = req.body;
    if (enabled) {
      await startBot();
    } else {
      stopBot();
    }
    res.json(getBotStatus());
  });

  return httpServer;
}
