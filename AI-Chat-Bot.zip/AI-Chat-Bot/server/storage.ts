import { db } from "./db";
import { 
  chatMessages, settings, telegramUsers,
  type ChatMessage, type InsertChatMessage, 
  type Setting, type InsertSetting,
  type TelegramUser, type InsertTelegramUser
} from "@shared/schema";
import { eq, desc, sql } from "drizzle-orm";

export interface IStorage {
  // Messages
  getMessages(): Promise<ChatMessage[]>;
  addMessage(message: InsertChatMessage): Promise<ChatMessage>;
  clearMessages(): Promise<void>;

  // Settings
  getSetting(key: string): Promise<Setting | undefined>;
  updateSetting(setting: InsertSetting): Promise<Setting>;
  
  // Telegram Users
  getTelegramUser(telegramId: string): Promise<TelegramUser | undefined>;
  upsertTelegramUser(telegramId: string): Promise<TelegramUser>;
  updateTelegramUserStatus(telegramId: string, status: { isVip?: boolean, isBanned?: boolean }): Promise<TelegramUser>;
  getTotalUsersCount(): Promise<number>;
  getAllTelegramUserIds(): Promise<string[]>;

  // Initialize default settings
  initSettings(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getMessages(): Promise<ChatMessage[]> {
    return await db.select()
      .from(chatMessages)
      .orderBy(desc(chatMessages.createdAt))
      .limit(100);
  }

  async addMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const [newMessage] = await db.insert(chatMessages)
      .values(message)
      .returning();
    return newMessage;
  }

  async clearMessages(): Promise<void> {
    await db.delete(chatMessages);
  }

  async getSetting(key: string): Promise<Setting | undefined> {
    const [setting] = await db.select()
      .from(settings)
      .where(eq(settings.key, key));
    return setting;
  }

  async updateSetting(insertSetting: InsertSetting): Promise<Setting> {
    const [updated] = await db.insert(settings)
      .values(insertSetting)
      .onConflictDoUpdate({
        target: settings.key,
        set: { value: insertSetting.value }
      })
      .returning();
    return updated;
  }

  async getTelegramUser(telegramId: string): Promise<TelegramUser | undefined> {
    const [user] = await db.select()
      .from(telegramUsers)
      .where(eq(telegramUsers.telegramId, telegramId));
    return user;
  }

  async upsertTelegramUser(telegramId: string): Promise<TelegramUser> {
    const [user] = await db.insert(telegramUsers)
      .values({ telegramId })
      .onConflictDoNothing()
      .returning();
    
    if (!user) {
      return (await this.getTelegramUser(telegramId))!;
    }
    return user;
  }

  async updateTelegramUserStatus(telegramId: string, status: { isVip?: boolean, isBanned?: boolean }): Promise<TelegramUser> {
    const [updated] = await db.update(telegramUsers)
      .set(status)
      .where(eq(telegramUsers.telegramId, telegramId))
      .returning();
    return updated;
  }

  async getTotalUsersCount(): Promise<number> {
    const [result] = await db.select({ count: sql<number>`count(*)` }).from(telegramUsers);
    return Number(result.count);
  }

  async getAllTelegramUserIds(): Promise<string[]> {
    const users = await db.select({ telegramId: telegramUsers.telegramId }).from(telegramUsers);
    return users.map(u => u.telegramId);
  }

  async initSettings(): Promise<void> {
    const existing = await this.getSetting("system_prompt");
    if (!existing) {
      await this.updateSetting({
        key: "system_prompt",
        value: "You are a helpful AI assistant. Reply concisely."
      });
    }
  }
}

export const storage = new DatabaseStorage();
